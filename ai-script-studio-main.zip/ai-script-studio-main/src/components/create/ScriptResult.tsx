import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { Copy, RefreshCw, Save } from "lucide-react";

interface ScriptResultProps {
  generatedScript: string;
  onCopy: () => void;
  onRegenerate: () => void;
  onSave: () => void;
}

export function ScriptResult({ generatedScript, onCopy, onRegenerate, onSave }: ScriptResultProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-140px)]"
    >
      {/* Script View */}
      <Card className="lg:col-span-2 flex flex-col h-full overflow-hidden border-primary/20 shadow-lg">
        <CardHeader className="border-b bg-muted/30 pb-4">
          <div className="flex items-center justify-between">
            <CardTitle>Generated Script</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={onCopy}>
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={onRegenerate}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 p-0 overflow-hidden">
          <ScrollArea className="h-full p-6">
            <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed">
              {generatedScript}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Actions Panel */}
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Next Steps</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full" variant="default" onClick={onSave}>
              <Save className="w-4 h-4 mr-2" />
              Save to Account
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              Save your script to access it later from any device.
            </p>
            <Separator />
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Export Options</h4>
              <Button variant="outline" className="w-full justify-start">
                Export to PDF
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Send to Email
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-primary/5 border-primary/10">
          <CardContent className="p-4">
            <h4 className="font-bold text-primary mb-2">Pro Tip</h4>
            <p className="text-sm text-muted-foreground">
              Try recording the hook 3 different ways to see which one performs best!
            </p>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
