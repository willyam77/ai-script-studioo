import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { CONTENT_TYPES } from "./ContentTypeSelector";

interface ScriptFormProps {
  selectedType: string;
  formData: any;
  setFormData: (data: any) => void;
  onGenerate: () => void;
}

export function ScriptForm({ selectedType, formData, setFormData, onGenerate }: ScriptFormProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl mx-auto"
    >
      <Card>
        <CardHeader>
          <CardTitle>
            {CONTENT_TYPES.find(t => t.id === selectedType)?.label} Details
          </CardTitle>
          <CardDescription>Fill in the details to generate your script</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Topic / Core Message</Label>
            <Input 
              placeholder="e.g. How to bake sourdough bread" 
              value={formData.topic || ""}
              onChange={(e) => setFormData({...formData, topic: e.target.value})}
            />
          </div>

          {/* Dynamic Fields based on Type */}
          {selectedType === "youtube_long" && (
            <>
              <div className="space-y-2">
                <Label>Target Audience</Label>
                <Input 
                  placeholder="e.g. Beginners, Home Cooks" 
                  value={formData.audience || ""}
                  onChange={(e) => setFormData({...formData, audience: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Duration (minutes)</Label>
                <Select onValueChange={(v) => setFormData({...formData, duration: v})}>
                  <SelectTrigger><SelectValue placeholder="Select duration" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="8">8 minutes</SelectItem>
                    <SelectItem value="10">10 minutes</SelectItem>
                    <SelectItem value="12">12 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Key Points (Optional)</Label>
                <Textarea 
                  placeholder="- Ingredients needed&#10;- Mixing process&#10;- Baking temperature"
                  value={formData.keyPoints || ""}
                  onChange={(e) => setFormData({...formData, keyPoints: e.target.value})}
                />
              </div>
            </>
          )}

          {["tiktok", "shorts", "reels", "linkedin_video"].includes(selectedType!) && (
            <>
              <div className="space-y-2">
                <Label>Hook Style</Label>
                <div className="grid grid-cols-2 gap-2">
                  {["Emotional", "Educational", "Entertaining", "Surprising"].map((hook) => (
                    <Button
                      key={hook}
                      type="button"
                      variant={formData.hookType === hook.toLowerCase() ? "default" : "outline"}
                      className="justify-start"
                      onClick={() => setFormData({...formData, hookType: hook.toLowerCase()})}
                    >
                      {hook}
                    </Button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Duration</Label>
                <div className="flex gap-2">
                  {["15", "30", "45", "60"].map((sec) => (
                    <Button
                      key={sec}
                      type="button"
                      variant={formData.duration === sec ? "default" : "outline"}
                      onClick={() => setFormData({...formData, duration: sec})}
                      className="flex-1"
                    >
                      {sec}s
                    </Button>
                  ))}
                </div>
              </div>
              <div className="space-y-4 pt-2">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="cta" 
                    checked={!!formData.ctaType}
                    onCheckedChange={(checked) => {
                      if (!checked) {
                        const { ctaType, ...rest } = formData;
                        setFormData(rest);
                      } else {
                        setFormData({...formData, ctaType: "follow"});
                      }
                    }}
                  />
                  <Label htmlFor="cta">Include Call to Action</Label>
                </div>
                {formData.ctaType && (
                  <Select 
                    value={formData.ctaType} 
                    onValueChange={(v) => setFormData({...formData, ctaType: v})}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="follow">Follow for more</SelectItem>
                      <SelectItem value="save">Save for later</SelectItem>
                      <SelectItem value="link">Link in bio</SelectItem>
                      <SelectItem value="comment">Leave a comment</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>
            </>
          )}

          <Button 
            className="w-full text-lg py-6" 
            onClick={onGenerate}
            disabled={!formData.topic}
          >
            <Sparkles className="mr-2 w-5 h-5" />
            Generate Script
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
