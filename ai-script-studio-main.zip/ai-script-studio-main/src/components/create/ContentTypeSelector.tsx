import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Video, FileText, Youtube, Instagram, Linkedin, Twitter } from "lucide-react";

export const CONTENT_TYPES = [
  { id: "youtube_long", label: "YouTube Long Form", icon: Youtube, desc: "8-15 min educational content", category: "video" },
  { id: "tiktok", label: "TikTok Video", icon: Video, desc: "15-60 sec viral content", category: "video" },
  { id: "shorts", label: "YouTube Shorts", icon: Youtube, desc: "30-60 sec vertical video", category: "video" },
  { id: "reels", label: "Instagram Reel", icon: Instagram, desc: "15-90 sec engaging video", category: "video" },
  { id: "linkedin_video", label: "LinkedIn Video", icon: Linkedin, desc: "1-3 min professional video", category: "video" },
  { id: "blog_post", label: "Blog Post", icon: FileText, desc: "SEO optimized article", category: "written" },
  { id: "newsletter", label: "Newsletter", icon: FileText, desc: "Email campaign content", category: "written" },
  { id: "social_post", label: "Social Media Post", icon: Twitter, desc: "Twitter/LinkedIn text", category: "written" },
];

interface ContentTypeSelectorProps {
  onSelect: (typeId: string) => void;
}

export function ContentTypeSelector({ onSelect }: ContentTypeSelectorProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">What are you creating today?</h2>
        <p className="text-muted-foreground">Choose a format to get started</p>
      </div>

      <Tabs defaultValue="video" className="w-full">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
          <TabsTrigger value="video">Video Scripts</TabsTrigger>
          <TabsTrigger value="written">Written Content</TabsTrigger>
        </TabsList>
        
        <TabsContent value="video" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CONTENT_TYPES.filter(t => t.category === "video").map((type) => (
            <ContentTypeCard key={type.id} type={type} onSelect={onSelect} />
          ))}
        </TabsContent>
        
        <TabsContent value="written" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CONTENT_TYPES.filter(t => t.category === "written").map((type) => (
            <ContentTypeCard key={type.id} type={type} onSelect={onSelect} />
          ))}
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}

function ContentTypeCard({ type, onSelect }: { type: any, onSelect: (id: string) => void }) {
  return (
    <Card 
      className="cursor-pointer hover:border-primary hover:shadow-md transition-all group"
      onClick={() => onSelect(type.id)}
    >
      <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
        <div className="p-3 rounded-full bg-muted group-hover:bg-primary/10 transition-colors">
          <type.icon className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
        <div>
          <h3 className="font-bold text-lg">{type.label}</h3>
          <p className="text-sm text-muted-foreground mt-1">{type.desc}</p>
        </div>
      </CardContent>
    </Card>
  );
}
