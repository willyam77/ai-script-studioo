"use node";
import { createVlyIntegrations } from "@vly-ai/integrations";

// Initialize the Vly client
// We are using OpenRouter directly in ai.ts now, but keeping this valid to prevent build errors
// if it's imported elsewhere or if we switch back.
let vly: any;

export function getVly() {
  if (vly) return vly;

  try {
    // Initialize with a dummy token to satisfy the type checker
    // We aren't using this instance for the actual AI calls anymore
    vly = createVlyIntegrations({
      deploymentToken: "unused"
    });
    return vly;
  } catch (error) {
    console.error("Failed to initialize Vly:", error);
    // Return a mock or throw depending on needs, but for now just throw
    throw error;
  }
}