import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema(
  {
    ...authTables,
    
    users: defineTable({
      name: v.optional(v.string()),
      image: v.optional(v.string()),
      email: v.optional(v.string()),
      emailVerificationTime: v.optional(v.number()),
      isAnonymous: v.optional(v.boolean()),
      tokenIdentifier: v.optional(v.string()),
    })
    .index("email", ["email"])
    .index("by_token", ["tokenIdentifier"]),

    scripts: defineTable({
      userId: v.optional(v.id("users")),
      title: v.string(),
      type: v.string(),
      content: v.string(),
      inputs: v.any(),
      isSaved: v.boolean(),
    })
    .index("by_user", ["userId"]),
  },
  { schemaValidation: false }
);