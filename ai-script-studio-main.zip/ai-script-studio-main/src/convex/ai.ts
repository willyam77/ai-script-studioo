"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";
import axios from "axios";

const VIDEO_MODEL_CONFIG = {
  short_viral: "openai/gpt-4o-mini",
  educational_long: "openai/gpt-4o-mini", 
  platform_specific: "openai/gpt-4o-mini",
  budget: "openai/gpt-4o-mini",
};

function selectModel(contentType: string) {
  if (contentType === "youtube_long") return VIDEO_MODEL_CONFIG.educational_long;
  if (["tiktok", "shorts", "reels"].includes(contentType)) return VIDEO_MODEL_CONFIG.short_viral;
  return "openai/gpt-4o-mini"; 
}

function enhancePromptWithHooks(basePrompt: string, hookType: string, ctaType: string) {
  const hooks: Record<string, string> = {
    'emotional': "Start with an emotional hook that makes the viewer feel something immediately.",
    'educational': "Start with a surprising fact or statistic that 90% of people don't know.",
    'question': "Start with a provocative question that the viewer must answer in their head.",
    'controversial': "Start with a controversial statement that challenges common beliefs.",
    'story': "Start with a personal story that creates immediate relatability.",
    'entertaining': "Start with a joke or a funny observation to grab attention.",
    'surprising': "Start with a shocking statement or visual.",
  };
  
  const ctas: Record<string, string> = {
    'follow': "End with a clear follow/subscribe call-to-action that tells the viewer exactly what to do next.",
    'save': "End with a save/bookmark CTA that encourages saving for later reference.",
    'link': "End with a 'link in bio' CTA for further resources.",
    'comment': "End with a comment CTA that encourages engagement on the platform.",
    'share': "End with a share CTA that encourages sharing with specific people.",
    'download': "End with a download CTA for a free resource.",
    'visit': "End with a CTA to visit a specific website.",
    'buy': "End with a CTA to purchase a product with a discount code.",
  };
  
  const hookText = hooks[hookType] || "";
  const ctaText = ctas[ctaType] || "";
  
  return `${hookText}\n\n${basePrompt}\n\n${ctaText}`;
}

export const generateScript = action({
  args: {
    type: v.string(),
    inputs: v.any(),
  },
  handler: async (ctx, args) => {
    try {
      const { type, inputs } = args;
      
      console.log("=== AI Generation Started ===");
      console.log("Content Type:", type);
      
      // 1. API Key Handling
      const apiKey = process.env.OPENROUTER_API_KEY;
      
      if (!apiKey) {
        throw new ConvexError("Missing OPENROUTER_API_KEY - Please add it in the Integrations tab");
      }
      
      console.log("API Key status:", apiKey ? `Present (length: ${apiKey.length})` : "Missing");
      
      // 2. Prompt Construction
      const safeInputs = {
        topic: inputs?.topic || "a topic",
        audience: inputs?.audience || "general audience",
        duration: inputs?.duration || "short",
        keyPoints: inputs?.keyPoints || "",
        hookType: inputs?.hookType || "",
        ctaType: inputs?.ctaType || "",
      };

      let systemPrompt = "You are an expert content creator and scriptwriter.";
      let prompt = "";

      if (type === "youtube_long") {
        systemPrompt = "You are a professional video scriptwriter specializing in long-form YouTube content.";
        prompt = `Create a YouTube video script about: ${safeInputs.topic}\n\nAUDIENCE: ${safeInputs.audience}\nDURATION: ${safeInputs.duration} minutes\nKEY POINTS: ${safeInputs.keyPoints}\n\nSTRUCTURE REQUIREMENTS:\n1. OPENING HOOK (First 30 seconds): Must capture attention and state value\n2. INTRO (30-60 seconds): What they'll learn, why it matters\n3. MAIN CONTENT (Timestamps every 2-3 minutes):\n   - [00:00-02:00] Section 1 with clear visual cues\n   - [02:00-04:00] Section 2 with B-roll suggestions\n   - Continue for duration...\n4. CONCLUSION (Last minute): Recap and next steps\n5. CTA: Subscribe, like, comment, visit link\n\nFORMAT OUTPUT AS:\n[TIMESTAMP] [VISUAL DESCRIPTION]\n[SPEAKER DIALOGUE]\n[ON-SCREEN TEXT SUGGESTION]\n[B-ROLL IDEA]`;
      } else if (["tiktok", "shorts", "reels", "linkedin_video"].includes(type)) {
        systemPrompt = `You are a viral ${type} creator.`;
        let basePrompt = `Create a ${type} video script about: ${safeInputs.topic}\n\nPLATFORM: ${type}\nDURATION: ${safeInputs.duration} seconds\nHOOK TYPE: ${safeInputs.hookType}\n\nCRITICAL REQUIREMENTS:\n1. HOOK (First 3 seconds): Must stop the scroll immediately.\n2. SCENE BREAKDOWN (3-second scenes):\n   - Scene 1 (0-3s): [Visual] + [Dialogue]\n   - Scene 2 (3-6s): [Visual] + [Dialogue]\n   - Continue for duration...\n3. CTA (Last 3 seconds): Make it clear and actionable.\n\nSCRIPT FORMAT:\n[0-3s] HOOK: [Visual description] | [Dialogue]\n[3-6s] SCENE 1: [Visual] | "Dialogue with exact wording"\n[6-9s] SCENE 2: [Visual] | "Dialogue"\n...\n[Last 3s] CTA: [Visual CTA frame] | "Follow for more tips!" + Arrow pointing to follow button\n\nInclude relevant trending audio suggestions and hashtags.`;

        prompt = enhancePromptWithHooks(basePrompt, safeInputs.hookType, safeInputs.ctaType);
      } else if (type === "blog_post") {
          systemPrompt = "You are a professional blog post writer.";
          prompt = `Write a blog post about: ${safeInputs.topic}\n\nAudience: ${safeInputs.audience}\nKey Points: ${safeInputs.keyPoints}`;
      } else {
          prompt = `Create content for ${type} about ${safeInputs.topic}.`;
      }

      const model = selectModel(type);
      console.log("Selected Model:", model);
      
      // 3. API Request using Axios
      console.log("Making request to OpenRouter...");
      
      const response = await axios.post(
        "https://openrouter.ai/api/v1/chat/completions",
        {
          model: model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: prompt }
          ],
          max_tokens: 2000,
        },
        {
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "HTTP-Referer": "https://vly.ai",
            "X-Title": "AI Script Studio",
          },
          timeout: 60000, // 60 second timeout
        }
      );

      if (response.data && response.data.choices && response.data.choices.length > 0) {
        const content = response.data.choices[0].message.content;
        console.log("=== AI Generation Complete ===");
        return content || "No response generated.";
      }
      
      throw new ConvexError("No response generated from AI.");

    } catch (error: any) {
      console.error("=== AI Generation Error ===");
      console.error("Error type:", error?.constructor?.name);
      console.error("Error message:", error?.message);
      console.error("Full error object:", error);
      
      if (axios.isAxiosError(error)) {
        const status = error.response?.status;
        const data = error.response?.data;
        console.error("Axios Error Details:", { 
          status, 
          statusText: error.response?.statusText,
          data,
          headers: error.response?.headers 
        });

        if (status === 401) {
          throw new ConvexError("Invalid OpenRouter API Key");
        } else if (status === 402) {
          throw new ConvexError("Insufficient credits");
        } else if (status === 429) {
          throw new ConvexError("Rate limit exceeded");
        } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
          throw new ConvexError("Request timeout - generation took too long");
        }
        
        const msg = data?.error?.message || error.message || "Unknown API error";
        throw new ConvexError(`OpenRouter Error: ${msg}`);
      }

      // If it's already a ConvexError, re-throw it
      if (error instanceof ConvexError) {
        throw error;
      }
      
      // Catch any other error and wrap it
      const errorMsg = error?.message || error?.toString() || "An unexpected error occurred during script generation.";
      console.error("Throwing ConvexError with message:", errorMsg);
      throw new ConvexError(errorMsg);
    }
  },
});