import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const saveScript = mutation({
  args: {
    title: v.string(),
    type: v.string(),
    content: v.string(),
    inputs: v.any(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    const scriptId = await ctx.db.insert("scripts", {
      userId: userId || undefined,
      title: args.title,
      type: args.type,
      content: args.content,
      inputs: args.inputs,
      isSaved: true,
    });

    return scriptId;
  },
});

export const getMyScripts = query({
  args: {},
  handler: async (ctx) => {
    try {
      const userId = await getAuthUserId(ctx);
      if (!userId) return [];

      return await ctx.db
        .query("scripts")
        .withIndex("by_user", (q) => q.eq("userId", userId))
        .order("desc")
        .collect();
    } catch (error) {
      console.error("Error in scripts:getMyScripts:", error);
      return [];
    }
  },
});

export const getScript = query({
  args: { id: v.id("scripts") },
  handler: async (ctx, args) => {
    const script = await ctx.db.get(args.id);
    return script;
  },
});