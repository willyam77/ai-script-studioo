"use node";
import { action } from "./_generated/server";

/**
 * Debug action to check environment variables
 */
export const checkEnv = action({
  args: {},
  handler: async () => {
    return {
      hasConvexSiteUrl: !!process.env.CONVEX_SITE_URL,
      convexSiteUrl: process.env.CONVEX_SITE_URL,
      nodeEnv: process.env.NODE_ENV,
      hasOpenRouterKey: !!process.env.OPENROUTER_API_KEY,
      openRouterKeyLength: process.env.OPENROUTER_API_KEY?.length,
    };
  },
});