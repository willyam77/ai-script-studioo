import { getAuthUserId } from "@convex-dev/auth/server";
import { query } from "./_generated/server";

export const currentUser = query({
  args: {},
  handler: async (ctx) => {
    try {
      const userId = await getAuthUserId(ctx);
      
      if (userId === null) {
        return null;
      }
      
      const user = await ctx.db.get(userId);
      return user;
    } catch (error) {
      // Log the error but don't throw - return null to prevent client crash
      console.error("Error in users:currentUser:", error);
      return null;
    }
  },
});