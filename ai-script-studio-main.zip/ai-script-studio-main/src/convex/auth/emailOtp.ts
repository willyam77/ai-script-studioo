import { Email } from "@convex-dev/auth/providers/Email";

export const emailOtp = Email({
  id: "email-otp",
  maxAge: 60 * 15, // 15 minutes
  async generateVerificationToken() {
    // Simple 6 digit OTP using standard Math.random
    return Math.floor(100000 + Math.random() * 900000).toString();
  },
  async sendVerificationRequest({ identifier: email, token }) {
    try {
      // Use fetch instead of axios for better compatibility with Convex runtime
      const response = await fetch("https://email.vly.ai/send_otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "vlytothemoon2025",
        },
        body: JSON.stringify({
          to: email,
          otp: token,
          appName: "AI Script Studio",
        }),
      });

      if (!response.ok) {
        console.error(`Failed to send OTP: ${response.status} ${response.statusText}`);
        // Don't throw, just log, to prevent crashing the auth flow if email service is down
        // The user just won't get the email, but the app won't crash
      }
    } catch (error) {
      console.error("Failed to send OTP:", error);
      // Don't throw
    }
  },
});