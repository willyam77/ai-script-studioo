import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router";
import { Home } from "lucide-react";
import { AnimatedBackground } from "@/components/AnimatedBackground";

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative">
      <AnimatedBackground />
      
      <div className="text-center space-y-6 relative z-10">
        <h1 className="text-9xl font-bold text-primary">404</h1>
        <h2 className="text-3xl font-bold">Page Not Found</h2>
        <p className="text-muted-foreground">The page you're looking for doesn't exist.</p>
        <Button onClick={() => navigate("/")} size="lg">
          <Home className="mr-2 w-4 h-4" />
          Go Home
        </Button>
      </div>
    </div>
  );
}