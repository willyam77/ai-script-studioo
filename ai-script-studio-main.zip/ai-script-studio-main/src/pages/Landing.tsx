import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Video, FileText, Zap } from "lucide-react";
import { useNavigate } from "react-router";
import { AnimatedBackground } from "@/components/AnimatedBackground";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-hidden relative">
      <AnimatedBackground />
      
      {/* Navbar */}
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto w-full relative z-10">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <div className="bg-primary text-primary-foreground p-1.5 rounded-lg">
            <Sparkles className="w-5 h-5" />
          </div>
          AI Script Studio
        </div>
        <div className="flex gap-4">
          <Button variant="ghost" onClick={() => navigate("/auth")}>Sign In</Button>
          <Button onClick={() => navigate("/create")}>Get Started</Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 relative z-10">
        {/* Background Elements */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl -z-10" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted text-sm font-medium text-muted-foreground mb-4">
            <Zap className="w-4 h-4 text-yellow-500" />
            <span>No account needed. Start creating immediately.</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-tight">
            Write your next viral <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-600">
              video script
            </span>{" "}
            in 30 seconds
          </h1>

          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Generate engaging scripts for YouTube, TikTok, Reels, and more. 
            Professional formatting, hook suggestions, and viral structures built-in.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
            <Button 
              size="lg" 
              className="text-lg px-8 py-6 h-auto rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
              onClick={() => navigate("/create")}
            >
              Create Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <p className="text-sm text-muted-foreground sm:hidden">No credit card required</p>
          </div>
        </motion.div>

        {/* Feature Grid Preview */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full px-4"
        >
          {[
            { icon: Video, title: "Video Scripts", desc: "YouTube, TikTok, Reels & more" },
            { icon: FileText, title: "Written Content", desc: "Blogs, Newsletters & Posts" },
            { icon: Sparkles, title: "AI Powered", desc: "Viral hooks & structured formats" },
          ].map((feature, i) => (
            <div key={i} className="p-6 rounded-2xl border bg-card/50 backdrop-blur-sm hover:border-primary/50 transition-colors text-left">
              <feature.icon className="w-10 h-10 text-primary mb-4" />
              <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </motion.div>
      </main>

      <footer className="py-8 text-center text-sm text-muted-foreground relative z-10">
        © {new Date().getFullYear()} AI Script Studio.
      </footer>
    </div>
  );
}