import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useAction, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { toast } from "sonner";
import { Loader2, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/use-auth";
import { ContentTypeSelector } from "@/components/create/ContentTypeSelector";
import { ScriptForm } from "@/components/create/ScriptForm";
import { ScriptResult } from "@/components/create/ScriptResult";
import { AnimatedBackground } from "@/components/AnimatedBackground";

type Step = "SELECTION" | "FORM" | "GENERATING" | "RESULT";

export default function Create() {
  const [step, setStep] = useState<Step>("SELECTION");
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({});
  const [generatedScript, setGeneratedScript] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  const generateScript = useAction(api.ai.generateScript);
  const saveScriptMutation = useMutation(api.scripts.saveScript);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleTypeSelect = (typeId: string) => {
    setSelectedType(typeId);
    setStep("FORM");
    // Reset form data when type changes
    setFormData({});
  };

  const handleGenerate = async () => {
    if (!selectedType) return;
    
    setIsGenerating(true);
    setStep("GENERATING");
    
    try {
      // Sanitize formData to remove undefined/null values which might cause issues
      const cleanFormData = Object.fromEntries(
        Object.entries(formData).filter(([_, v]) => v !== undefined && v !== null)
      );

      const result = await generateScript({
        type: selectedType,
        inputs: cleanFormData,
      });
      setGeneratedScript(result);
      setStep("RESULT");
    } catch (error: any) {
      console.error("Generation error:", error);
      
      // Extract the error message
      // ConvexError messages are often in error.data or error.message
      let msg = "Unknown error";
      
      if (error.data) {
        msg = error.data;
      } else if (error.message) {
        msg = error.message;
      }
      
      // Clean up the message if it contains the Convex wrapper text
      if (msg.includes("[CONVEX")) {
         // Try to extract the actual message if possible
         // Example: [CONVEX A(ai:generateScript)] ... Error: Actual message
         const parts = msg.split("Error: ");
         if (parts.length > 1) {
             msg = parts[1];
         }
      }

      if (msg.includes("Missing OPENROUTER_API_KEY")) {
        toast.error("Configuration Error", {
            description: "Please add OPENROUTER_API_KEY in the Integrations tab.",
            duration: 10000,
        });
      } else if (msg.includes("Invalid OpenRouter API Key")) {
        toast.error("Authentication Error", {
            description: "The API Key provided is invalid. Please check it in the Integrations tab.",
            duration: 10000,
        });
      } else if (msg.includes("Insufficient credits")) {
        toast.error("Payment Required", {
            description: "Your OpenRouter account has insufficient credits.",
            duration: 10000,
        });
      } else {
        toast.error("Generation Failed", {
            description: msg,
            duration: 10000, // Longer duration to read error
            action: {
                label: "Retry",
                onClick: handleGenerate
            }
        });
      }
      setStep("FORM");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!isAuthenticated) {
      toast("Please sign in to save your script", {
        action: {
          label: "Sign In",
          onClick: () => navigate("/auth?redirect=/create"),
        },
      });
      return;
    }

    try {
      await saveScriptMutation({
        title: formData.topic || "Untitled Script",
        type: selectedType!,
        content: generatedScript,
        inputs: formData,
      });
      toast.success("Script saved to your account!");
    } catch (error) {
      toast.error("Failed to save script");
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedScript);
    toast.success("Copied to clipboard");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col relative">
      <AnimatedBackground />
      
      <header className="border-b p-4 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-10">
        <div className="flex items-center gap-4">
          {step !== "SELECTION" && (
            <Button variant="ghost" size="icon" onClick={() => setStep("SELECTION")}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
          )}
          <h1 className="font-bold text-lg">
            {step === "SELECTION" ? "New Project" : 
             step === "FORM" ? "Script Details" : 
             step === "GENERATING" ? "Creating Magic..." : "Your Script"}
          </h1>
        </div>
        <Button variant="ghost" size="sm" onClick={() => navigate("/")}>Exit</Button>
      </header>

      <main className="flex-1 container mx-auto max-w-5xl p-4 md:p-8 relative z-10">
        <AnimatePresence mode="wait">
          {step === "SELECTION" && (
            <ContentTypeSelector onSelect={handleTypeSelect} />
          )}

          {step === "FORM" && selectedType && (
            <ScriptForm 
              selectedType={selectedType}
              formData={formData}
              setFormData={setFormData}
              onGenerate={handleGenerate}
            />
          )}

          {step === "GENERATING" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center h-[60vh] text-center space-y-6"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse" />
                <Loader2 className="w-16 h-16 animate-spin text-primary relative z-10" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Crafting your script...</h3>
                <p className="text-muted-foreground">Our AI is analyzing viral trends and structuring your content.</p>
              </div>
            </motion.div>
          )}

          {step === "RESULT" && (
            <ScriptResult 
              generatedScript={generatedScript}
              onCopy={copyToClipboard}
              onRegenerate={handleGenerate}
              onSave={handleSave}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}